# QuotesApp
This project contains the web App QuotesApp
